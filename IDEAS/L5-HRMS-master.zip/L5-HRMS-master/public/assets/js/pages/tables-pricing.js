'use strict';
//  Author: ThemeREX.com
//  tables-pricing.html scripts
//

(function ($) {

    $(document).ready(function () {

        "use strict";

        // Init Demo JS
        Demo.init();


        // Init Theme Core
        Core.init();

    });

})(jQuery);
